# skill.py — Wikipedia lookup: select a word/topic, get a clean summary.
# Uses Wikipedia's free public REST + MediaWiki APIs (no key, no cost).
# Output is a clean, search-engine-style answer (no [1] reference markers).

import re
import ssl
import json
from urllib import request, parse

import bridge

_UA = "Scryptian/1.0 (https://github.com/adrianium/Scryptian)"
_MAX_QUERY = 300


def _ssl_ctx():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _lang_for(text):
    """Pick a Wikipedia language edition from the script of the query.

    Cyrillic input -> Russian Wikipedia, everything else -> English. Kept
    deliberately simple; the search API tolerates cross-language queries.
    """
    if re.search(r"[\u0400-\u04FF]", text):
        return "ru"
    return "en"


def _get_json(url):
    req = request.Request(url, headers={"User-Agent": _UA})
    with request.urlopen(req, timeout=10, context=_ssl_ctx()) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _search_title(lang, query):
    """Find the best matching article title (search-engine behaviour)."""
    api = (
        f"https://{lang}.wikipedia.org/w/api.php?action=query&list=search"
        f"&srsearch={parse.quote(query)}&srlimit=1&format=json"
    )
    try:
        data = _get_json(api)
        hits = data.get("query", {}).get("search", [])
        if hits:
            return hits[0].get("title")
    except Exception:
        pass
    return None


def _summary(lang, title):
    """Fetch the clean plain-text summary for a page title."""
    api = f"https://{lang}.wikipedia.org/api/rest_v1/page/summary/{parse.quote(title.replace(' ', '_'))}"
    return _get_json(api)


def _clean(text):
    """Strip any leftover reference markers and tidy whitespace."""
    text = re.sub(r"\[\d+\]", "", text)          # [1], [2] style refs
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def run(text):
    """
    text: the selected word/topic to look up on Wikipedia.
    Returns a clean summary (title + abstract + source link).
    """
    query = (text or "").strip()
    if not query:
        return "[Scryptian Error] Select a word or topic first."
    if len(query) > _MAX_QUERY:
        query = query[:_MAX_QUERY]

    # Language: user setting wins; "auto" (or unset) falls back to script detection.
    try:
        chosen = (bridge.get_state("wikipedia").get("settings", {}) or {}).get("lang", "auto")
    except Exception:
        chosen = "auto"
    lang = _lang_for(query) if chosen in ("", "auto", None) else chosen

    # 1) Resolve the query to the best-matching article title.
    title = _search_title(lang, query)
    if not title:
        return f"No Wikipedia article found for: {query}"

    # 2) Fetch the clean summary for that title.
    try:
        data = _summary(lang, title)
    except Exception as e:
        return f"[Scryptian Error] Could not reach Wikipedia: {e}"

    extract = _clean(data.get("extract", ""))
    if not extract:
        return f"No summary available for: {title}"

    return extract
